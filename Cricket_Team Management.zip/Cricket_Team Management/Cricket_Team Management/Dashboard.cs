﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cricket_Team_Management
{
    public partial class Dashboard : Form
    {
        public Dashboard()
        {
            InitializeComponent();
        }

        private void cOUNTRIESToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Countries ob = new Countries();
            ob.Show();
            this.Hide();
        }

        private void tEAMSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Teams ob = new Teams();
            ob.Show();
            this.Hide();
        }

        private void pLAYERSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Players ob = new Players();
            ob.Show();
            this.Hide();
        }

        private void mATCHESToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Matches ob = new Matches();
            ob.Show();
            this.Hide();
        }

        protected override void OnClosed(EventArgs e)
        {
            if (MessageBox.Show("Closing app Confirm?", "Close Application", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                Application.Exit();
            }
            else
            {
                this.Activate();
            }
        }
    }
}
