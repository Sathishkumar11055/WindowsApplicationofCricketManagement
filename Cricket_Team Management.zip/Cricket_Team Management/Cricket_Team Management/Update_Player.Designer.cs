﻿namespace Cricket_Team_Management
{
    partial class Update_Player
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtpid = new System.Windows.Forms.TextBox();
            this.paneldetails = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtpname = new System.Windows.Forms.TextBox();
            this.txtteamid = new System.Windows.Forms.TextBox();
            this.txtprole = new System.Windows.Forms.TextBox();
            this.txtpage = new System.Windows.Forms.TextBox();
            this.btnupdate = new System.Windows.Forms.Button();
            this.btnsearch = new System.Windows.Forms.Button();
            this.paneldetails.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(50, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "ENTER PLAYER ID";
            // 
            // txtpid
            // 
            this.txtpid.Location = new System.Drawing.Point(199, 39);
            this.txtpid.Name = "txtpid";
            this.txtpid.Size = new System.Drawing.Size(210, 20);
            this.txtpid.TabIndex = 1;
            // 
            // paneldetails
            // 
            this.paneldetails.Controls.Add(this.btnupdate);
            this.paneldetails.Controls.Add(this.txtpage);
            this.paneldetails.Controls.Add(this.txtprole);
            this.paneldetails.Controls.Add(this.txtteamid);
            this.paneldetails.Controls.Add(this.txtpname);
            this.paneldetails.Controls.Add(this.label5);
            this.paneldetails.Controls.Add(this.label4);
            this.paneldetails.Controls.Add(this.label3);
            this.paneldetails.Controls.Add(this.label2);
            this.paneldetails.Location = new System.Drawing.Point(53, 90);
            this.paneldetails.Name = "paneldetails";
            this.paneldetails.Size = new System.Drawing.Size(708, 312);
            this.paneldetails.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(52, 42);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "PLAYER NAME";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(52, 88);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "PLAYER AGE";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(52, 135);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 13);
            this.label4.TabIndex = 2;
            this.label4.Text = "PLAYER ROLE";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(52, 185);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 13);
            this.label5.TabIndex = 3;
            this.label5.Text = "TEAM ID";
            // 
            // txtpname
            // 
            this.txtpname.Location = new System.Drawing.Point(219, 37);
            this.txtpname.Name = "txtpname";
            this.txtpname.Size = new System.Drawing.Size(248, 20);
            this.txtpname.TabIndex = 4;
            // 
            // txtteamid
            // 
            this.txtteamid.Location = new System.Drawing.Point(219, 185);
            this.txtteamid.Name = "txtteamid";
            this.txtteamid.Size = new System.Drawing.Size(248, 20);
            this.txtteamid.TabIndex = 5;
            // 
            // txtprole
            // 
            this.txtprole.Location = new System.Drawing.Point(219, 128);
            this.txtprole.Name = "txtprole";
            this.txtprole.Size = new System.Drawing.Size(248, 20);
            this.txtprole.TabIndex = 6;
            // 
            // txtpage
            // 
            this.txtpage.Location = new System.Drawing.Point(219, 81);
            this.txtpage.Name = "txtpage";
            this.txtpage.Size = new System.Drawing.Size(248, 20);
            this.txtpage.TabIndex = 7;
            // 
            // btnupdate
            // 
            this.btnupdate.Location = new System.Drawing.Point(219, 248);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.Size = new System.Drawing.Size(118, 38);
            this.btnupdate.TabIndex = 8;
            this.btnupdate.Text = "UPDATE";
            this.btnupdate.UseVisualStyleBackColor = true;
            this.btnupdate.Click += new System.EventHandler(this.btnupdate_Click);
            // 
            // btnsearch
            // 
            this.btnsearch.Location = new System.Drawing.Point(495, 36);
            this.btnsearch.Name = "btnsearch";
            this.btnsearch.Size = new System.Drawing.Size(119, 23);
            this.btnsearch.TabIndex = 4;
            this.btnsearch.Text = "SEARCH DETAILS";
            this.btnsearch.UseVisualStyleBackColor = true;
            this.btnsearch.Click += new System.EventHandler(this.btnsearch_Click);
            // 
            // Update_Player
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnsearch);
            this.Controls.Add(this.paneldetails);
            this.Controls.Add(this.txtpid);
            this.Controls.Add(this.label1);
            this.Name = "Update_Player";
            this.Text = "Update_Player";
            this.Load += new System.EventHandler(this.Update_Player_Load);
            this.paneldetails.ResumeLayout(false);
            this.paneldetails.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtpid;
        private System.Windows.Forms.Panel paneldetails;
        private System.Windows.Forms.Button btnupdate;
        private System.Windows.Forms.TextBox txtpage;
        private System.Windows.Forms.TextBox txtprole;
        private System.Windows.Forms.TextBox txtteamid;
        private System.Windows.Forms.TextBox txtpname;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnsearch;
    }
}