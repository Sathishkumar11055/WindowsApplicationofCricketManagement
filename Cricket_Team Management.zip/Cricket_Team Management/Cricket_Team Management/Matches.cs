﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cricket_Team_Management
{
    public partial class Matches : Form
    {
        public Matches()
        {
            InitializeComponent();
        }
        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            Dashboard ob = new Dashboard();
            ob.Show();
            base.OnFormClosed(e);
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            Add_Match ob = new Add_Match();
            ob.Show();
            this.Hide();
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            Delete_Match ob = new Delete_Match();
            ob.Show();
            this.Hide();
        }

        private void btndisplay_Click(object sender, EventArgs e)
        {
            Display_Match ob = new Display_Match();
            ob.Show();
            this.Hide();
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            Update_Match ob = new Update_Match();
            ob.Show();
            this.Hide();
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            Search_Match ob = new Search_Match();
            ob.Show();
            this.Hide();
        }
    }
}

