﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Cricket_Team_Management
{
    public partial class Display_Match : Form
    {
        SqlConnection conn;
        public Display_Match()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb"].ConnectionString);
        }
        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            Matches ob = new Matches();
            ob.Show();
            base.OnFormClosed(e);
        }

        private void Display_Match_Load(object sender, EventArgs e)
        {
            string query = "select * from matches";
            //List<Country_Details> c = new List<Country_Details>();

            //MessageBox.Show(query);
            try
            {
                conn.Open();
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataSet ds = new DataSet("mydetails");
                da.Fill(ds);
                dgdisplay.DataSource = ds.Tables[0];
                //MessageBox.Show("Displayed records successfully");
                conn.Close();
            }
            catch (Exception ob)
            {
                MessageBox.Show(ob.Message);
            }
        }
    }
}
