﻿namespace Cricket_Team_Management
{
    partial class Search_Player
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnsearch = new System.Windows.Forms.Button();
            this.txtpid = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.paneldetails = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblid = new System.Windows.Forms.Label();
            this.lblname = new System.Windows.Forms.Label();
            this.lblage = new System.Windows.Forms.Label();
            this.lblrole = new System.Windows.Forms.Label();
            this.lblteamid = new System.Windows.Forms.Label();
            this.paneldetails.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnsearch
            // 
            this.btnsearch.Location = new System.Drawing.Point(517, 39);
            this.btnsearch.Name = "btnsearch";
            this.btnsearch.Size = new System.Drawing.Size(119, 23);
            this.btnsearch.TabIndex = 7;
            this.btnsearch.Text = "SEARCH DETAILS";
            this.btnsearch.UseVisualStyleBackColor = true;
            this.btnsearch.Click += new System.EventHandler(this.btnsearch_Click);
            // 
            // txtpid
            // 
            this.txtpid.Location = new System.Drawing.Point(221, 42);
            this.txtpid.Name = "txtpid";
            this.txtpid.Size = new System.Drawing.Size(210, 20);
            this.txtpid.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(72, 49);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "ENTER PLAYER ID";
            // 
            // paneldetails
            // 
            this.paneldetails.Controls.Add(this.lblteamid);
            this.paneldetails.Controls.Add(this.lblrole);
            this.paneldetails.Controls.Add(this.lblage);
            this.paneldetails.Controls.Add(this.lblname);
            this.paneldetails.Controls.Add(this.lblid);
            this.paneldetails.Controls.Add(this.label6);
            this.paneldetails.Controls.Add(this.label5);
            this.paneldetails.Controls.Add(this.label4);
            this.paneldetails.Controls.Add(this.label3);
            this.paneldetails.Controls.Add(this.label2);
            this.paneldetails.Location = new System.Drawing.Point(53, 98);
            this.paneldetails.Name = "paneldetails";
            this.paneldetails.Size = new System.Drawing.Size(708, 312);
            this.paneldetails.TabIndex = 8;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(56, 230);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 13);
            this.label5.TabIndex = 3;
            this.label5.Text = "TEAM ID";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(56, 180);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 13);
            this.label4.TabIndex = 2;
            this.label4.Text = "PLAYER ROLE";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(56, 133);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "PLAYER AGE";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(56, 87);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "PLAYER NAME";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(56, 43);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 13);
            this.label6.TabIndex = 4;
            this.label6.Text = "PLAYER ID";
            // 
            // lblid
            // 
            this.lblid.AutoSize = true;
            this.lblid.Location = new System.Drawing.Point(236, 42);
            this.lblid.Name = "lblid";
            this.lblid.Size = new System.Drawing.Size(35, 13);
            this.lblid.TabIndex = 5;
            this.lblid.Text = "label7";
            // 
            // lblname
            // 
            this.lblname.AutoSize = true;
            this.lblname.Location = new System.Drawing.Point(236, 87);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(35, 13);
            this.lblname.TabIndex = 6;
            this.lblname.Text = "label8";
            // 
            // lblage
            // 
            this.lblage.AutoSize = true;
            this.lblage.Location = new System.Drawing.Point(236, 133);
            this.lblage.Name = "lblage";
            this.lblage.Size = new System.Drawing.Size(35, 13);
            this.lblage.TabIndex = 7;
            this.lblage.Text = "label9";
            // 
            // lblrole
            // 
            this.lblrole.AutoSize = true;
            this.lblrole.Location = new System.Drawing.Point(236, 180);
            this.lblrole.Name = "lblrole";
            this.lblrole.Size = new System.Drawing.Size(41, 13);
            this.lblrole.TabIndex = 8;
            this.lblrole.Text = "label10";
            // 
            // lblteamid
            // 
            this.lblteamid.AutoSize = true;
            this.lblteamid.Location = new System.Drawing.Point(236, 230);
            this.lblteamid.Name = "lblteamid";
            this.lblteamid.Size = new System.Drawing.Size(41, 13);
            this.lblteamid.TabIndex = 9;
            this.lblteamid.Text = "label11";
            // 
            // Search_Player
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.paneldetails);
            this.Controls.Add(this.btnsearch);
            this.Controls.Add(this.txtpid);
            this.Controls.Add(this.label1);
            this.Name = "Search_Player";
            this.Text = "Search_Player";
            this.Load += new System.EventHandler(this.Search_Player_Load);
            this.paneldetails.ResumeLayout(false);
            this.paneldetails.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnsearch;
        private System.Windows.Forms.TextBox txtpid;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel paneldetails;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblteamid;
        private System.Windows.Forms.Label lblrole;
        private System.Windows.Forms.Label lblage;
        private System.Windows.Forms.Label lblname;
        private System.Windows.Forms.Label lblid;
        private System.Windows.Forms.Label label6;
    }
}