﻿using System;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cricket_Team_Management
{
    public partial class Add_Country : Form
    {
        SqlConnection conn;
        public Add_Country()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb"].ConnectionString);
        }

        private void btnsubmit_Click(object sender, EventArgs e)
        {
            string query = string.Format("insert into countries values({0},'{1}','{2}')", txtid.Value, txtname.Text, txtdesc.Text);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Country details added successfully");
                conn.Close();
            }
            catch(Exception ob)
            {
                MessageBox.Show(ob.Message);
            }
        }

        private void Add_Country_Load(object sender, EventArgs e)
        {

        }
       protected override void OnFormClosed(FormClosedEventArgs e)
        {
            Countries ob = new Countries();
            ob.Show();
            base.OnFormClosed(e);
        }
    }
}

