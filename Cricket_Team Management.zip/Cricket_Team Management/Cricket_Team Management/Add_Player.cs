﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Cricket_Team_Management
{
    public partial class Add_Player : Form
    {
        SqlConnection conn;
        public Add_Player()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb"].ConnectionString);
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void cmbteamname_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cmbteamid_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Add_Player_Load(object sender, EventArgs e)
        {
            string query = "select * from teams";
            try
            {
                conn.Open();
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataSet ds = new DataSet();
                da.Fill(ds);
                cmbteamid.DataSource = ds.Tables[0];
                cmbteamid.ValueMember = ds.Tables[0].Columns[0].ToString();
                cmbteamid.DisplayMember = ds.Tables[0].Columns[0].ToString();
                conn.Close();
            }
            catch (Exception ob)
            {
                MessageBox.Show(ob.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string query = string.Format("insert into players values({0},'{1}', {2}, '{3}', {4})", txtid.Value, txtname.Text, txtage.Text, txtrole.Text, cmbteamid.Text);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Player added successfully");
                conn.Close();
            }
            catch (Exception ob)
            {
                MessageBox.Show(ob.Message);
            }
        }
        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            Players ob = new Players();
            ob.Show();
            base.OnFormClosed(e);
        }
    }
}
