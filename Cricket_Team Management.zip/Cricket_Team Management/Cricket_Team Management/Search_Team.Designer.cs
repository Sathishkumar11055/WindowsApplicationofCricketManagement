﻿namespace Cricket_Team_Management
{
    partial class Search_Team
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel = new System.Windows.Forms.Panel();
            this.lblcid = new System.Windows.Forms.Label();
            this.lbltname = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnsearch = new System.Windows.Forms.Button();
            this.txttid = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.sadas = new System.Windows.Forms.Label();
            this.lblid = new System.Windows.Forms.Label();
            this.panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txttid)).BeginInit();
            this.SuspendLayout();
            // 
            // panel
            // 
            this.panel.Controls.Add(this.lblid);
            this.panel.Controls.Add(this.sadas);
            this.panel.Controls.Add(this.lblcid);
            this.panel.Controls.Add(this.lbltname);
            this.panel.Controls.Add(this.label2);
            this.panel.Controls.Add(this.label3);
            this.panel.Location = new System.Drawing.Point(67, 121);
            this.panel.Margin = new System.Windows.Forms.Padding(2);
            this.panel.Name = "panel";
            this.panel.Size = new System.Drawing.Size(571, 215);
            this.panel.TabIndex = 10;
            // 
            // lblcid
            // 
            this.lblcid.AutoSize = true;
            this.lblcid.Location = new System.Drawing.Point(346, 120);
            this.lblcid.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblcid.Name = "lblcid";
            this.lblcid.Size = new System.Drawing.Size(35, 13);
            this.lblcid.TabIndex = 15;
            this.lblcid.Text = "label5";
            // 
            // lbltname
            // 
            this.lbltname.AutoSize = true;
            this.lbltname.Location = new System.Drawing.Point(346, 78);
            this.lbltname.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbltname.Name = "lbltname";
            this.lbltname.Size = new System.Drawing.Size(35, 13);
            this.lbltname.TabIndex = 14;
            this.lbltname.Text = "label4";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(191, 78);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 13);
            this.label2.TabIndex = 13;
            this.label2.Text = "TEAM NAME";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(191, 120);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "COUNTRY ID";
            // 
            // btnsearch
            // 
            this.btnsearch.Location = new System.Drawing.Point(502, 49);
            this.btnsearch.Margin = new System.Windows.Forms.Padding(2);
            this.btnsearch.Name = "btnsearch";
            this.btnsearch.Size = new System.Drawing.Size(136, 22);
            this.btnsearch.TabIndex = 9;
            this.btnsearch.Text = "SEARCH ID";
            this.btnsearch.UseVisualStyleBackColor = true;
            this.btnsearch.Click += new System.EventHandler(this.btnsearch_Click);
            // 
            // txttid
            // 
            this.txttid.Location = new System.Drawing.Point(264, 49);
            this.txttid.Margin = new System.Windows.Forms.Padding(2);
            this.txttid.Name = "txttid";
            this.txttid.Size = new System.Drawing.Size(184, 20);
            this.txttid.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(99, 54);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "ENTER TEAM ID";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // sadas
            // 
            this.sadas.AutoSize = true;
            this.sadas.Location = new System.Drawing.Point(194, 38);
            this.sadas.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.sadas.Name = "sadas";
            this.sadas.Size = new System.Drawing.Size(51, 13);
            this.sadas.TabIndex = 16;
            this.sadas.Text = "TEAM ID";
            // 
            // lblid
            // 
            this.lblid.AutoSize = true;
            this.lblid.Location = new System.Drawing.Point(346, 38);
            this.lblid.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblid.Name = "lblid";
            this.lblid.Size = new System.Drawing.Size(35, 13);
            this.lblid.TabIndex = 17;
            this.lblid.Text = "label4";
            // 
            // Search_Team
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel);
            this.Controls.Add(this.btnsearch);
            this.Controls.Add(this.txttid);
            this.Controls.Add(this.label1);
            this.Name = "Search_Team";
            this.Text = "Search_Team";
            this.Load += new System.EventHandler(this.Search_Team_Load);
            this.panel.ResumeLayout(false);
            this.panel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txttid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel;
        private System.Windows.Forms.Label lblcid;
        private System.Windows.Forms.Label lbltname;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnsearch;
        private System.Windows.Forms.NumericUpDown txttid;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblid;
        private System.Windows.Forms.Label sadas;
    }
}