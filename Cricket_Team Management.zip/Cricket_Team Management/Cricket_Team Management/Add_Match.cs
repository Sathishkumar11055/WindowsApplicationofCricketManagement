﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Cricket_Team_Management
{
    public partial class Add_Match : Form
    {
        SqlConnection conn;
        public Add_Match()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb"].ConnectionString);
        }
        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            Matches ob = new Matches();
            ob.Show();
            base.OnFormClosed(e);
        }

        private void Add_Match_Load(object sender, EventArgs e)
        {
            string query = "select * from teams ";
            try
            {
                conn.Open();
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataSet ds = new DataSet();
                da.Fill(ds);
                cmbt1.DataSource = ds.Tables[0];
                cmbt1.ValueMember = ds.Tables[0].Columns[0].ToString();
                cmbt1.DisplayMember = ds.Tables[0].Columns[1].ToString();

                conn.Close();

            }
            catch (Exception ob)
            {
                MessageBox.Show(ob.Message);
            }

            try
            {
                conn.Open();
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataSet ds = new DataSet();
                da.Fill(ds);

                cmbt2.DataSource = ds.Tables[0];
                cmbt2.ValueMember = ds.Tables[0].Columns[0].ToString();
                cmbt2.DisplayMember = ds.Tables[0].Columns[1].ToString();
                conn.Close();

            }
            catch (Exception ob)
            {
                MessageBox.Show(ob.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string query = string.Format("insert into matches values({0},'{1}','{2}','{3}','{4}')", txtmid.Value, cmbt1.Text, cmbt2.Text, dtmatch.Value, txtstadium.Text);

            if (cmbt1.Text != cmbt2.Text)
            {
                try
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();

                    MessageBox.Show("match details added successfully");
                    conn.Close();
                }
                catch (Exception ob)
                {
                    MessageBox.Show(ob.Message);
                }
            }
            else
            {
               MessageBox.Show("Both Teams are same");
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
