﻿namespace Cricket_Team_Management
{
    partial class Search_Match
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblst = new System.Windows.Forms.Label();
            this.lbldt = new System.Windows.Forms.Label();
            this.lblt2 = new System.Windows.Forms.Label();
            this.lblt1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.txttid = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txttid)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lblst);
            this.panel1.Controls.Add(this.lbldt);
            this.panel1.Controls.Add(this.lblt2);
            this.panel1.Controls.Add(this.lblt1);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Location = new System.Drawing.Point(55, 126);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(687, 193);
            this.panel1.TabIndex = 13;
            // 
            // lblst
            // 
            this.lblst.AutoSize = true;
            this.lblst.Location = new System.Drawing.Point(399, 149);
            this.lblst.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblst.Name = "lblst";
            this.lblst.Size = new System.Drawing.Size(35, 13);
            this.lblst.TabIndex = 38;
            this.lblst.Text = "label9";
            // 
            // lbldt
            // 
            this.lbldt.AutoSize = true;
            this.lbldt.Location = new System.Drawing.Point(399, 106);
            this.lbldt.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbldt.Name = "lbldt";
            this.lbldt.Size = new System.Drawing.Size(35, 13);
            this.lbldt.TabIndex = 37;
            this.lbldt.Text = "label8";
            // 
            // lblt2
            // 
            this.lblt2.AutoSize = true;
            this.lblt2.Location = new System.Drawing.Point(399, 63);
            this.lblt2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblt2.Name = "lblt2";
            this.lblt2.Size = new System.Drawing.Size(35, 13);
            this.lblt2.TabIndex = 36;
            this.lblt2.Text = "label7";
            // 
            // lblt1
            // 
            this.lblt1.AutoSize = true;
            this.lblt1.Location = new System.Drawing.Point(399, 20);
            this.lblt1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblt1.Name = "lblt1";
            this.lblt1.Size = new System.Drawing.Size(35, 13);
            this.lblt1.TabIndex = 35;
            this.lblt1.Text = "label6";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(191, 149);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 13);
            this.label3.TabIndex = 34;
            this.label3.Text = "STADIUM";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(191, 106);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(94, 13);
            this.label2.TabIndex = 33;
            this.label2.Text = "DATE OF MATCH";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(191, 63);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 13);
            this.label4.TabIndex = 32;
            this.label4.Text = "TEAM 2";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(191, 20);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 13);
            this.label5.TabIndex = 31;
            this.label5.Text = "TEAM 1";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(561, 54);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(136, 22);
            this.button1.TabIndex = 12;
            this.button1.Text = "SEARCH ID";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txttid
            // 
            this.txttid.Location = new System.Drawing.Point(249, 54);
            this.txttid.Margin = new System.Windows.Forms.Padding(2);
            this.txttid.Name = "txttid";
            this.txttid.Size = new System.Drawing.Size(240, 20);
            this.txttid.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(52, 56);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "ENTER MATCH ID";
            // 
            // Search_Match
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txttid);
            this.Controls.Add(this.label1);
            this.Name = "Search_Match";
            this.Text = "Search_Match";
            this.Load += new System.EventHandler(this.Search_Match_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txttid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblst;
        private System.Windows.Forms.Label lbldt;
        private System.Windows.Forms.Label lblt2;
        private System.Windows.Forms.Label lblt1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.NumericUpDown txttid;
        private System.Windows.Forms.Label label1;
    }
}