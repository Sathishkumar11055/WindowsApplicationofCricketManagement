﻿using System;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cricket_Team_Management
{
    public partial class Display_Country : Form
    {
        SqlConnection conn;
        public Display_Country()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb"].ConnectionString);
        }

        private void dgdisplay_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
          

        }

        private void Display_Country_Load(object sender, EventArgs e)
        {
            string query = "select * from Countries ";
            List<Country_Details> c = new List<Country_Details>();
  
            //MessageBox.Show(query);
            try
            {
                conn.Open();
                
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataSet ds = new DataSet("mydetails");
                da.Fill(ds);
                dgdisplay.DataSource = ds.Tables[0];
                //MessageBox.Show("Displayed records successfully");
                conn.Close();
            }
            catch (Exception ob)
            {
                MessageBox.Show(ob.Message);
            }
        }
        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            Countries ob = new Countries();
            ob.Show();
            base.OnFormClosed(e);
        }
    }
}
