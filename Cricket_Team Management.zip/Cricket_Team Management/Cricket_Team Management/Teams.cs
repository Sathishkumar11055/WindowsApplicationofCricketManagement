﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cricket_Team_Management
{
    public partial class Teams : Form
    {
        public Teams()
        {
            InitializeComponent();
        }
        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            Dashboard ob = new Dashboard();
            ob.Show();
            base.OnFormClosed(e);
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            Add_Team ob = new Add_Team();
            ob.Show();
            this.Hide();
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            Delete_Team ob = new Delete_Team();
            ob.Show();
            this.Hide();
        }

        private void btndisplay_Click(object sender, EventArgs e)
        {
            Display_team ob = new Display_team();
            ob.Show();
            this.Hide();
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            Update_Team ob = new Update_Team();
            ob.Show();
            this.Hide();
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            Search_Team ob = new Search_Team();
            ob.Show();
            this.Hide();
        }
    }
}

