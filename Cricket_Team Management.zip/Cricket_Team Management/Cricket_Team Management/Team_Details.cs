﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cricket_Team_Management
{
    class Team_Details
    {
        public int teamid { get; set; }
        public string team_name { get; set; }
        public int countryid { get; set; }
    }
}
